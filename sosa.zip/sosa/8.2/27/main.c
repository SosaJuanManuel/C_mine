#include <stdio.h>
#include <stdlib.h>


void main(void)
{
    int i,valor;
    //int factorial = 1;
    int result =1;

    printf("ingrese un numero: ");
    scanf("%d",&valor);

    /*  if(valor < 0)
      {
          printf("\nno se pueden factorizar numeros negativos");
      }
      else
      {
          for(i=1; i<= valor; i++)
          {
              factorial *= i;
          }
          printf("\nel factorial del numero %d es %d\n",valor,factorial);
      }
    return 0;*/

    i=valor;
    if(valor < 0)
    {
        printf("\nno se pueden factorizar numeros negativos");
    }
    else
    {
        while(i>0)
        {
            result = result *i;
            i--;
        }
    }
    printf("el factorial de %d es %d",valor,result);
}


